/*
 Navicat Premium Data Transfer

 Source Server         : Euler203Gauss311db1
 Source Server Type    : PostgreSQL
 Source Server Version : 90204 (90204)
 Source Host           : 192.168.75.129:26000
 Source Catalog        : DBSystem
 Source Schema         : zjutuser

 Target Server Type    : PostgreSQL
 Target Server Version : 90204 (90204)
 File Encoding         : 65001

 Date: 09/07/2023 16:17:16
*/


-- ----------------------------
-- Table structure for Zhangjw_Classes15
-- ----------------------------
DROP TABLE IF EXISTS "zjutuser"."Zhangjw_Classes15";
CREATE TABLE "zjutuser"."Zhangjw_Classes15" (
  "zjw_CLno15" varchar(20) COLLATE "pg_catalog"."default" NOT NULL,
  "zjw_CLname15" varchar(50) COLLATE "pg_catalog"."default",
  "zjw_Mno15" varchar(20) COLLATE "pg_catalog"."default"
)
;

-- ----------------------------
-- Records of Zhangjw_Classes15
-- ----------------------------
INSERT INTO "zjutuser"."Zhangjw_Classes15" VALUES ('0101', '网络工程01', '031501');
INSERT INTO "zjutuser"."Zhangjw_Classes15" VALUES ('0201', '软件工程01', '031502');
INSERT INTO "zjutuser"."Zhangjw_Classes15" VALUES ('1302', '土木工程02', '080902');
INSERT INTO "zjutuser"."Zhangjw_Classes15" VALUES ('0301', '计算机科学与技术01', '091003');

-- ----------------------------
-- Table structure for Zhangjw_CourseClass15
-- ----------------------------
DROP TABLE IF EXISTS "zjutuser"."Zhangjw_CourseClass15";
CREATE TABLE "zjutuser"."Zhangjw_CourseClass15" (
  "zjw_Cno15" varchar(20) COLLATE "pg_catalog"."default",
  "zjw_CLno15" varchar(20) COLLATE "pg_catalog"."default"
)
;

-- ----------------------------
-- Records of Zhangjw_CourseClass15
-- ----------------------------
INSERT INTO "zjutuser"."Zhangjw_CourseClass15" VALUES ('G120001', '0101');
INSERT INTO "zjutuser"."Zhangjw_CourseClass15" VALUES ('G120002', '0101');
INSERT INTO "zjutuser"."Zhangjw_CourseClass15" VALUES ('G120001', '0201');

-- ----------------------------
-- Table structure for Zhangjw_Courses15
-- ----------------------------
DROP TABLE IF EXISTS "zjutuser"."Zhangjw_Courses15";
CREATE TABLE "zjutuser"."Zhangjw_Courses15" (
  "zjw_Cno15" varchar(20) COLLATE "pg_catalog"."default" NOT NULL,
  "zjw_Cname15" varchar(50) COLLATE "pg_catalog"."default",
  "zjw_Chour15" int4,
  "zjw_Tname15" varchar(50) COLLATE "pg_catalog"."default",
  "zjw_Cterm15" varchar(20) COLLATE "pg_catalog"."default",
  "zjw_Assessment_Type15" varchar(50) COLLATE "pg_catalog"."default",
  "zjw_Credit15" int4
)
;

-- ----------------------------
-- Records of Zhangjw_Courses15
-- ----------------------------
INSERT INTO "zjutuser"."Zhangjw_Courses15" VALUES ('G120001', '数据库原理及其应用', 4, '范闲', '大二下', '考试', 3);
INSERT INTO "zjutuser"."Zhangjw_Courses15" VALUES ('G120002', '计算机组成原理', 4, '田贤忠', '大二下', '考试', 3);
INSERT INTO "zjutuser"."Zhangjw_Courses15" VALUES ('G120003', '计算机网络', 4, '叶域鑫', '大二上', '考试', 3);
INSERT INTO "zjutuser"."Zhangjw_Courses15" VALUES ('G140302', '高等数学', 4, '叶域鑫', '大一下', '考试', 4);

-- ----------------------------
-- Table structure for Zhangjw_Majors15
-- ----------------------------
DROP TABLE IF EXISTS "zjutuser"."Zhangjw_Majors15";
CREATE TABLE "zjutuser"."Zhangjw_Majors15" (
  "zjw_Mno15" varchar(20) COLLATE "pg_catalog"."default" NOT NULL,
  "zjw_Mname15" varchar(50) COLLATE "pg_catalog"."default"
)
;

-- ----------------------------
-- Records of Zhangjw_Majors15
-- ----------------------------
INSERT INTO "zjutuser"."Zhangjw_Majors15" VALUES ('031501', '网络工程');
INSERT INTO "zjutuser"."Zhangjw_Majors15" VALUES ('031502', '软件工程');
INSERT INTO "zjutuser"."Zhangjw_Majors15" VALUES ('080902', '土木工程');
INSERT INTO "zjutuser"."Zhangjw_Majors15" VALUES ('091003', '计算机科学与技术');

-- ----------------------------
-- Table structure for Zhangjw_Reports15
-- ----------------------------
DROP TABLE IF EXISTS "zjutuser"."Zhangjw_Reports15";
CREATE TABLE "zjutuser"."Zhangjw_Reports15" (
  "zjw_Sno15" varchar(20) COLLATE "pg_catalog"."default",
  "zjw_Cno15" varchar(20) COLLATE "pg_catalog"."default",
  "zjw_Cterm15" varchar(20) COLLATE "pg_catalog"."default",
  "zjw_Grade15" int4,
  "zjw_Tno15" varchar(20) COLLATE "pg_catalog"."default"
)
;

-- ----------------------------
-- Records of Zhangjw_Reports15
-- ----------------------------
INSERT INTO "zjutuser"."Zhangjw_Reports15" VALUES ('202103150101', 'G120001', '大二下', 95, '06564');
INSERT INTO "zjutuser"."Zhangjw_Reports15" VALUES ('202103150203', 'G120001', '大二下', 86, '06564');

-- ----------------------------
-- Table structure for Zhangjw_Students15
-- ----------------------------
DROP TABLE IF EXISTS "zjutuser"."Zhangjw_Students15";
CREATE TABLE "zjutuser"."Zhangjw_Students15" (
  "zjw_Sno15" varchar(20) COLLATE "pg_catalog"."default" NOT NULL,
  "zjw_Sname15" varchar(50) COLLATE "pg_catalog"."default",
  "zjw_Ssex15" varchar(10) COLLATE "pg_catalog"."default",
  "zjw_Sage15" int4,
  "zjw_Location15" varchar(50) COLLATE "pg_catalog"."default",
  "zjw_Scredit15" int4,
  "zjw_CLno15" varchar(20) COLLATE "pg_catalog"."default",
  "zjw_Spassword15" varchar(50) COLLATE "pg_catalog"."default"
)
;

-- ----------------------------
-- Records of Zhangjw_Students15
-- ----------------------------
INSERT INTO "zjutuser"."Zhangjw_Students15" VALUES ('202103150102', '王嘉兴', '女', 21, '浙江温州', 0, '0101', '123456');
INSERT INTO "zjutuser"."Zhangjw_Students15" VALUES ('202103150713', '王建华', '男', 22, '浙江杭州', 0, '1302', '123456');
INSERT INTO "zjutuser"."Zhangjw_Students15" VALUES ('202103150101', '李强', '男', 20, '浙江杭州', 3, '0101', '123456');
INSERT INTO "zjutuser"."Zhangjw_Students15" VALUES ('202103150203', '俞初心', '女', 20, '浙江温州', 6, '0201', '123456');
INSERT INTO "zjutuser"."Zhangjw_Students15" VALUES ('2021030624', '清秋', '男', 22, '山东济南', 0, '1302', '123456');

-- ----------------------------
-- Table structure for Zhangjw_Teachers15
-- ----------------------------
DROP TABLE IF EXISTS "zjutuser"."Zhangjw_Teachers15";
CREATE TABLE "zjutuser"."Zhangjw_Teachers15" (
  "zjw_Tno15" varchar(20) COLLATE "pg_catalog"."default" NOT NULL,
  "zjw_Tname15" varchar(50) COLLATE "pg_catalog"."default",
  "zjw_Tsex15" varchar(10) COLLATE "pg_catalog"."default",
  "zjw_Tage15" int4,
  "zjw_Tjob15" varchar(50) COLLATE "pg_catalog"."default",
  "zjw_Tphone15" varchar(20) COLLATE "pg_catalog"."default",
  "zjw_Tpassword15" varchar(50) COLLATE "pg_catalog"."default"
)
;

-- ----------------------------
-- Records of Zhangjw_Teachers15
-- ----------------------------
INSERT INTO "zjutuser"."Zhangjw_Teachers15" VALUES ('06564', '范闲', '男', 45, '普通教师', '0576-84184848', '123456');
INSERT INTO "zjutuser"."Zhangjw_Teachers15" VALUES ('06555', '叶域鑫', '男', 32, '普通教师', '0576-84184123', '123456');
INSERT INTO "zjutuser"."Zhangjw_Teachers15" VALUES ('06423', '蔡超亿', '女', 56, '普通教师', '0576-84156343', '123456');
INSERT INTO "zjutuser"."Zhangjw_Teachers15" VALUES ('02634', '田贤忠', '男', 51, '管理员', '0571-85290116', '123456');
INSERT INTO "zjutuser"."Zhangjw_Teachers15" VALUES ('03201', '李强', '男', 37, '普通教师', '0576-84180303', '123456');
INSERT INTO "zjutuser"."Zhangjw_Teachers15" VALUES ('05601', '叶清宇', '男', 56, '教授', '13057684429', '123456');

-- ----------------------------
-- Function structure for Zhangjw_addscore15
-- ----------------------------
DROP FUNCTION IF EXISTS "zjutuser"."Zhangjw_addscore15"();
CREATE OR REPLACE FUNCTION "zjutuser"."Zhangjw_addscore15"()
  RETURNS "pg_catalog"."trigger" AS $BODY$
DECLARE
	tmp INT;
BEGIN
	
	SELECT "zjw_Credit15"
	INTO tmp
	FROM "Zhangjw_Courses15"
	WHERE "zjw_Cno15"=NEW."zjw_Cno15";
	
	UPDATE "Zhangjw_Students15"
	SET "zjw_Scredit15" = CASE
		WHEN NEW."zjw_Grade15">=60 THEN
			"zjw_Scredit15"+tmp
		ELSE
			"zjw_Scredit15"
	END
	WHERE "Zhangjw_Students15"."zjw_Sno15"=NEW."zjw_Sno15";
	RETURN NEW;
END
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;

-- ----------------------------
-- Function structure for Zhangjw_addstu15
-- ----------------------------
DROP FUNCTION IF EXISTS "zjutuser"."Zhangjw_addstu15"();
CREATE OR REPLACE FUNCTION "zjutuser"."Zhangjw_addstu15"()
  RETURNS "pg_catalog"."trigger" AS $BODY$
BEGIN
	
	UPDATE "Zhangjw_Students15"
	SET "zjw_Spassword15"='123456'
	WHERE "zjw_Sno15"=NEW."zjw_Sno15";

	RETURN NEW;
END
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;

-- ----------------------------
-- Function structure for Zhangjw_addtea15
-- ----------------------------
DROP FUNCTION IF EXISTS "zjutuser"."Zhangjw_addtea15"();
CREATE OR REPLACE FUNCTION "zjutuser"."Zhangjw_addtea15"()
  RETURNS "pg_catalog"."trigger" AS $BODY$
BEGIN
	
	UPDATE "Zhangjw_Teachers15"
	SET "zjw_Tpassword15"='123456'
	WHERE "zjw_Tno15"=NEW."zjw_Tno15";

	RETURN NEW;
END
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;

-- ----------------------------
-- Function structure for Zhangjw_queryadminpwd15
-- ----------------------------
DROP FUNCTION IF EXISTS "zjutuser"."Zhangjw_queryadminpwd15"("username" text, "password" text);
CREATE OR REPLACE FUNCTION "zjutuser"."Zhangjw_queryadminpwd15"("username" text, "password" text)
  RETURNS "pg_catalog"."int4" AS $BODY$
DECLARE
	tmp TEXT;
BEGIN
	
	SELECT COUNT(*)
	INTO tmp
	FROM "Zhangjw_Teachers15"
	WHERE "zjw_Tno15"=username AND "zjw_Tpassword15"=password AND "zjw_Tjob15"='管理员';
	
	IF tmp=0 THEN RETURN 0;
	ELSE RETURN 1;
	END IF;

END
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;

-- ----------------------------
-- Function structure for Zhangjw_querystudentpwd15
-- ----------------------------
DROP FUNCTION IF EXISTS "zjutuser"."Zhangjw_querystudentpwd15"("username" text, "password" text);
CREATE OR REPLACE FUNCTION "zjutuser"."Zhangjw_querystudentpwd15"("username" text, "password" text)
  RETURNS "pg_catalog"."int4" AS $BODY$
DECLARE
	tmp TEXT;
BEGIN
	
	SELECT COUNT(*)
	INTO tmp
	FROM "Zhangjw_Students15"
	WHERE "zjw_Sno15"=username AND "zjw_Spassword15"=password;
	
	IF tmp=0 THEN RETURN 0;
	ELSE RETURN 1;
	END IF;

END
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;

-- ----------------------------
-- Function structure for Zhangjw_queryteacherpwd15
-- ----------------------------
DROP FUNCTION IF EXISTS "zjutuser"."Zhangjw_queryteacherpwd15"("username" text, "password" text);
CREATE OR REPLACE FUNCTION "zjutuser"."Zhangjw_queryteacherpwd15"("username" text, "password" text)
  RETURNS "pg_catalog"."int4" AS $BODY$
DECLARE
	tmp TEXT;
BEGIN
	
	SELECT COUNT(*)
	INTO tmp
	FROM "Zhangjw_Teachers15"
	WHERE "zjw_Tno15"=username AND "zjw_Tpassword15"=password AND "zjw_Tjob15"<>'管理员';
	
	IF tmp=0 THEN RETURN 0;
	ELSE RETURN 1;
	END IF;

END
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;

-- ----------------------------
-- Function structure for max
-- ----------------------------
DROP FUNCTION IF EXISTS "zjutuser"."max"("a" int4, "b" int4);
CREATE OR REPLACE FUNCTION "zjutuser"."max"("a" int4, "b" int4)
  RETURNS "pg_catalog"."int4" AS $BODY$
DECLARE
	tmp INT;
BEGIN
	
	IF a>b THEN tmp=a;
	ELSE tmp=b;
	END IF;
	
	RETURN tmp;
END
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;

-- ----------------------------
-- View structure for Zhangjw_GradeInfo15
-- ----------------------------
DROP VIEW IF EXISTS "zjutuser"."Zhangjw_GradeInfo15";
CREATE VIEW "zjutuser"."Zhangjw_GradeInfo15" AS  SELECT r."zjw_Sno15" AS "zjw_StudentNumber15", 
    s."zjw_Sname15" AS "zjw_StudentName15", 
    cl."zjw_CLname15" AS "zjw_ClassName15", 
    r."zjw_Cno15" AS "zjw_CourseNumber15", 
    c."zjw_Cname15" AS "zjw_CourseName15", r."zjw_Grade15", 
    t."zjw_Tname15" AS "zjw_TeacherName15", 
    c."zjw_Cterm15" AS "zjw_CourseTerm15"
   FROM zjutuser."Zhangjw_Reports15" r
   JOIN zjutuser."Zhangjw_Students15" s ON r."zjw_Sno15"::text = s."zjw_Sno15"::text
   JOIN zjutuser."Zhangjw_Courses15" c ON r."zjw_Cno15"::text = c."zjw_Cno15"::text
   JOIN zjutuser."Zhangjw_Teachers15" t ON r."zjw_Tno15"::text = t."zjw_Tno15"::text
   JOIN zjutuser."Zhangjw_Classes15" cl ON s."zjw_CLno15"::text = cl."zjw_CLno15"::text;

-- ----------------------------
-- View structure for Zhangjw_CreditInfo15
-- ----------------------------
DROP VIEW IF EXISTS "zjutuser"."Zhangjw_CreditInfo15";
CREATE VIEW "zjutuser"."Zhangjw_CreditInfo15" AS  SELECT gi."zjw_StudentNumber15", gi."zjw_StudentName15", gi."zjw_ClassName15", 
    gi."zjw_CourseName15", c."zjw_Chour15" AS "zjw_CourseHours15", 
    c."zjw_Credit15" AS "zjw_CourseCredit15", gi."zjw_Grade15", 
    gi."zjw_CourseTerm15", 
    zjutuser.max(0, gi."zjw_Grade15" - 50) / 10 AS "zjw_PGA15"
   FROM zjutuser."Zhangjw_GradeInfo15" gi
   JOIN zjutuser."Zhangjw_Courses15" c ON gi."zjw_CourseNumber15"::text = c."zjw_Cno15"::text;

-- ----------------------------
-- View structure for Zhangjw_StudentInfo15
-- ----------------------------
DROP VIEW IF EXISTS "zjutuser"."Zhangjw_StudentInfo15";
CREATE VIEW "zjutuser"."Zhangjw_StudentInfo15" AS  SELECT s."zjw_Sno15" AS "zjw_StudentNumber15", 
    s."zjw_Sname15" AS "zjw_StudentName15", 
    s."zjw_Ssex15" AS "zjw_StudentSex15", s."zjw_Sage15" AS "zjw_StudentAge15", 
    s."zjw_Location15", m."zjw_Mname15" AS "zjw_MajorName15", 
    cl."zjw_CLname15" AS "zjw_ClassName15", 
    s."zjw_Scredit15" AS "zjw_StudentCredit15"
   FROM zjutuser."Zhangjw_Students15" s
   JOIN zjutuser."Zhangjw_Classes15" cl ON s."zjw_CLno15"::text = cl."zjw_CLno15"::text
   JOIN zjutuser."Zhangjw_Majors15" m ON m."zjw_Mno15"::text = cl."zjw_Mno15"::text;

-- ----------------------------
-- View structure for Zhangjw_ClassInfo15
-- ----------------------------
DROP VIEW IF EXISTS "zjutuser"."Zhangjw_ClassInfo15";
CREATE VIEW "zjutuser"."Zhangjw_ClassInfo15" AS  SELECT cr."zjw_Cname15" AS "zjw_CourseName15", 
    cr."zjw_Credit15" AS "zjw_CourseCredit15", 
    cr."zjw_Chour15" AS "zjw_CourseHours15", 
    cr."zjw_Assessment_Type15" AS "zjw_AssessmentType15", 
    cr."zjw_Cno15" AS "zjw_CourseNumber15", 
    cl."zjw_CLname15" AS "zjw_ClassName15", 
    cr."zjw_Cterm15" AS "zjw_CourseTerm15", 
    cr."zjw_Tname15" AS "zjw_TeacherName15"
   FROM zjutuser."Zhangjw_Classes15" cl
   JOIN zjutuser."Zhangjw_CourseClass15" cc ON cl."zjw_CLno15"::text = cc."zjw_CLno15"::text
   JOIN zjutuser."Zhangjw_Courses15" cr ON cc."zjw_Cno15"::text = cr."zjw_Cno15"::text;

-- ----------------------------
-- Indexes structure for table Zhangjw_Classes15
-- ----------------------------
CREATE UNIQUE INDEX "Zhangjw_Classes_index15" ON "zjutuser"."Zhangjw_Classes15" USING btree (
  "zjw_CLno15" COLLATE "pg_catalog"."default" "pg_catalog"."text_ops" ASC NULLS LAST
);

-- ----------------------------
-- Primary Key structure for table Zhangjw_Classes15
-- ----------------------------
ALTER TABLE "zjutuser"."Zhangjw_Classes15" ADD CONSTRAINT "Zhangjw_Classes15_pkey" PRIMARY KEY ("zjw_CLno15");

-- ----------------------------
-- Indexes structure for table Zhangjw_Courses15
-- ----------------------------
CREATE UNIQUE INDEX "Zhangjw_Courses_index15" ON "zjutuser"."Zhangjw_Courses15" USING btree (
  "zjw_Cno15" COLLATE "pg_catalog"."default" "pg_catalog"."text_ops" ASC NULLS LAST
);

-- ----------------------------
-- Primary Key structure for table Zhangjw_Courses15
-- ----------------------------
ALTER TABLE "zjutuser"."Zhangjw_Courses15" ADD CONSTRAINT "Zhangjw_Courses15_pkey" PRIMARY KEY ("zjw_Cno15");

-- ----------------------------
-- Primary Key structure for table Zhangjw_Majors15
-- ----------------------------
ALTER TABLE "zjutuser"."Zhangjw_Majors15" ADD CONSTRAINT "Zhangjw_Majors15_pkey" PRIMARY KEY ("zjw_Mno15");

-- ----------------------------
-- Indexes structure for table Zhangjw_Reports15
-- ----------------------------
CREATE UNIQUE INDEX "Zhangjw_Reports_index15" ON "zjutuser"."Zhangjw_Reports15" USING btree (
  "zjw_Sno15" COLLATE "pg_catalog"."default" "pg_catalog"."text_ops" ASC NULLS LAST,
  "zjw_Cno15" COLLATE "pg_catalog"."default" "pg_catalog"."text_ops" ASC NULLS LAST
);

-- ----------------------------
-- Triggers structure for table Zhangjw_Reports15
-- ----------------------------
CREATE TRIGGER "Zhangjw_addscore15" AFTER INSERT ON "zjutuser"."Zhangjw_Reports15"
FOR EACH ROW
EXECUTE PROCEDURE "zjutuser"."Zhangjw_addscore15"();

-- ----------------------------
-- Indexes structure for table Zhangjw_Students15
-- ----------------------------
CREATE UNIQUE INDEX "Zhangjw_Students_index15" ON "zjutuser"."Zhangjw_Students15" USING btree (
  "zjw_Sno15" COLLATE "pg_catalog"."default" "pg_catalog"."text_ops" ASC NULLS LAST
);

-- ----------------------------
-- Triggers structure for table Zhangjw_Students15
-- ----------------------------
CREATE TRIGGER "Zhangjw_addstu15" AFTER INSERT ON "zjutuser"."Zhangjw_Students15"
FOR EACH ROW
EXECUTE PROCEDURE "zjutuser"."Zhangjw_addstu15"();

-- ----------------------------
-- Primary Key structure for table Zhangjw_Students15
-- ----------------------------
ALTER TABLE "zjutuser"."Zhangjw_Students15" ADD CONSTRAINT "Zhangjw_Students15_pkey" PRIMARY KEY ("zjw_Sno15");

-- ----------------------------
-- Indexes structure for table Zhangjw_Teachers15
-- ----------------------------
CREATE UNIQUE INDEX "Zhangjw_Teachers_index15" ON "zjutuser"."Zhangjw_Teachers15" USING btree (
  "zjw_Tno15" COLLATE "pg_catalog"."default" "pg_catalog"."text_ops" ASC NULLS LAST
);

-- ----------------------------
-- Triggers structure for table Zhangjw_Teachers15
-- ----------------------------
CREATE TRIGGER "Zhangjw_addtea15" AFTER INSERT ON "zjutuser"."Zhangjw_Teachers15"
FOR EACH ROW
EXECUTE PROCEDURE "zjutuser"."Zhangjw_addtea15"();

-- ----------------------------
-- Primary Key structure for table Zhangjw_Teachers15
-- ----------------------------
ALTER TABLE "zjutuser"."Zhangjw_Teachers15" ADD CONSTRAINT "Zhangjw_Teachers15_pkey" PRIMARY KEY ("zjw_Tno15");

-- ----------------------------
-- Foreign Keys structure for table Zhangjw_Classes15
-- ----------------------------
ALTER TABLE "zjutuser"."Zhangjw_Classes15" ADD CONSTRAINT "Zhangjw_Classes15_zjw_Mno15_fkey" FOREIGN KEY ("zjw_Mno15") REFERENCES "zjutuser"."Zhangjw_Majors15" ("zjw_Mno15") ON DELETE NO ACTION ON UPDATE NO ACTION;

-- ----------------------------
-- Foreign Keys structure for table Zhangjw_CourseClass15
-- ----------------------------
ALTER TABLE "zjutuser"."Zhangjw_CourseClass15" ADD CONSTRAINT "Zhangjw_CourseClass15_zjw_CLno15_fkey" FOREIGN KEY ("zjw_CLno15") REFERENCES "zjutuser"."Zhangjw_Classes15" ("zjw_CLno15") ON DELETE NO ACTION ON UPDATE NO ACTION;
ALTER TABLE "zjutuser"."Zhangjw_CourseClass15" ADD CONSTRAINT "Zhangjw_CourseClass15_zjw_Cno15_fkey" FOREIGN KEY ("zjw_Cno15") REFERENCES "zjutuser"."Zhangjw_Courses15" ("zjw_Cno15") ON DELETE NO ACTION ON UPDATE NO ACTION;

-- ----------------------------
-- Foreign Keys structure for table Zhangjw_Reports15
-- ----------------------------
ALTER TABLE "zjutuser"."Zhangjw_Reports15" ADD CONSTRAINT "Zhangjw_Reports15_zjw_Cno15_fkey" FOREIGN KEY ("zjw_Cno15") REFERENCES "zjutuser"."Zhangjw_Courses15" ("zjw_Cno15") ON DELETE NO ACTION ON UPDATE NO ACTION;
ALTER TABLE "zjutuser"."Zhangjw_Reports15" ADD CONSTRAINT "Zhangjw_Reports15_zjw_Sno15_fkey" FOREIGN KEY ("zjw_Sno15") REFERENCES "zjutuser"."Zhangjw_Students15" ("zjw_Sno15") ON DELETE NO ACTION ON UPDATE NO ACTION;
ALTER TABLE "zjutuser"."Zhangjw_Reports15" ADD CONSTRAINT "Zhangjw_Reports15_zjw_Tno15_fkey" FOREIGN KEY ("zjw_Tno15") REFERENCES "zjutuser"."Zhangjw_Teachers15" ("zjw_Tno15") ON DELETE NO ACTION ON UPDATE NO ACTION;

-- ----------------------------
-- Foreign Keys structure for table Zhangjw_Students15
-- ----------------------------
ALTER TABLE "zjutuser"."Zhangjw_Students15" ADD CONSTRAINT "Zhangjw_Students15_zjw_CLno15_fkey" FOREIGN KEY ("zjw_CLno15") REFERENCES "zjutuser"."Zhangjw_Classes15" ("zjw_CLno15") ON DELETE NO ACTION ON UPDATE NO ACTION;
