package com.example.education_administration_system;

import java.util.ArrayList;

public interface TeacherDao extends Dao {

    public ArrayList<Record> queryTeacherCourse(String opt, String query_value);

    public ArrayList<Record> queryScoreAvg(String opt, String query_value);

    public ArrayList<Record> queryScoreRank(String opt, String query_value);

    public Boolean importStudent(Record record);
}
