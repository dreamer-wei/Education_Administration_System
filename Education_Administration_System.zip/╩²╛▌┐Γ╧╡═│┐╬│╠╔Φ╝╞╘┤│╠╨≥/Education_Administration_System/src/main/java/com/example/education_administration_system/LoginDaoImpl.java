package com.example.education_administration_system;

import java.sql.*;
import java.util.ArrayList;

public class LoginDaoImpl implements LoginDao {
    public int queryPwd(String username, String password, String role) {
        int ans = 0;
        try {
            Connection conn = getConnection();
            CallableStatement stat = role.equals("1") ? conn.prepareCall("{?=call \"Zhangjw_queryadminpwd15\"(?,?)}") : (role.equals("2") ? conn.prepareCall("{?=call \"Zhangjw_queryteacherpwd15\"(?,?)}") : conn.prepareCall("{?=call \"Zhangjw_querystudentpwd15\"(?,?)}"));
            stat.registerOutParameter(1, Types.INTEGER);
            stat.setString(2, username);
            stat.setString(3, password);
            stat.execute();
            ans = stat.getInt(1);
            Dao.closeAll(conn, stat, null);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ans;
    }

    public ArrayList<String> queryPwd(String username, String role) {
        ArrayList<String> res = new ArrayList<>();
        String table, pwd, num;
        if (!role.equals("3")) {
            table = "Zhangjw_Teachers15";
            pwd = "zjw_Tpassword15";
            num = "zjw_Tno15";
        } else {
            table = "Zhangjw_Students15";
            pwd = "zjw_Spassword15";
            num = "zjw_Sno15";
        }
        try {
            Connection conn = getConnection();
            PreparedStatement stat = conn.prepareStatement("SELECT \"" + pwd + "\" FROM \"" + table + "\" WHERE \"" + num + "\"=" + username);
            ResultSet rs = stat.executeQuery();
            while (rs.next()) {
                res.add(rs.getString(pwd));
            }
            Dao.closeAll(conn, stat, rs);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return res;
    }

    public boolean updatePwd(String username, String oldpwd, String newpwd, String role) {
        ArrayList<String> res = queryPwd(username, role);
        if (!res.get(0).equals(oldpwd)) {
            return false;
        }
        String table, pwd, num;
        if (!role.equals("3")) {
            table = "Zhangjw_Teachers15";
            pwd = "zjw_Tpassword15";
            num = "zjw_Tno15";
        } else {
            table = "Zhangjw_Stuents15";
            pwd = "zjw_Spassword15";
            num = "zjw_Sno15";
        }
        try {
            Connection conn = getConnection();
            PreparedStatement stat = conn.prepareStatement("UPDATE ? SET ?=? WHERE ?=? AND ?=?");
            stat.setString(1, table);
            stat.setString(2, pwd);
            stat.setString(3, newpwd);
            stat.setString(4, num);
            stat.setString(5, username);
            stat.setString(6, pwd);
            stat.setString(7, oldpwd);
            stat.executeUpdate();
            Dao.closeAll(conn, stat, null);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return true;
    }
}
