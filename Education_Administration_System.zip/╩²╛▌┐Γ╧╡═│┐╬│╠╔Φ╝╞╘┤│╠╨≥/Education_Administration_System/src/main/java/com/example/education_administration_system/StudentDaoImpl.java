package com.example.education_administration_system;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class StudentDaoImpl implements StudentDao {
    @Override
    public ArrayList<Record> queryClassCourse(String opt, String query_value) {
        ArrayList<Record> records = new ArrayList<>();
        String str = "";
        if (opt.equals("2")) {
            str = " WHERE \"zjw_ClassName15\"=?;";
        }
        try {
            Connection conn = getConnection();
            query_value = new String(query_value.getBytes("iso-8859-1"), "UTF-8");
            String sql = "SELECT * FROM \"Zhangjw_ClassInfo15\"" + str;
            PreparedStatement stat = conn.prepareStatement(sql);
            if (!opt.equals("1")) {
                stat.setString(1, query_value);
            }
            ResultSet rs = stat.executeQuery();
            while (rs.next()) {
                Record record = new Record();
                record.setCourseName(rs.getString("zjw_CourseName15"));
                record.setCourseCredit(rs.getString("zjw_CourseCredit15"));
                record.setCoursePeriod(rs.getString("zjw_CourseHours15"));
                record.setCourseExamination(rs.getString("zjw_AssessmentType15"));
                record.setCourseNumber(rs.getString("zjw_CourseNumber15"));
                record.setClassName(rs.getString("zjw_ClassName15"));
                record.setCourseTerm(rs.getString("zjw_CourseTerm15"));
                record.setTeacherName(rs.getString("zjw_TeacherName15"));
                records.add(record);
            }
            Dao.closeAll(conn, stat, rs);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return records;
    }

    @Override
    public ArrayList<Record> queryTeacherCourse(String opt, String query_value) {
        ArrayList<Record> records = new ArrayList<>();
        String str = "";
        if (opt.equals("2")) {
            str = " WHERE \"zjw_Tname15\"=?;";
        }
        try {
            Connection conn = getConnection();
            query_value = new String(query_value.getBytes("iso-8859-1"), "UTF-8");
            String sql = "SELECT * FROM \"Zhangjw_Courses15\"" + str;
            PreparedStatement stat = conn.prepareStatement(sql);
            if (!opt.equals("1")) {
                stat.setString(1, query_value);
            }
            ResultSet rs = stat.executeQuery();
            while (rs.next()) {
                Record record = new Record();
                record.setCourseName(rs.getString("zjw_Cname15"));
                record.setCourseCredit(rs.getString("zjw_Credit15"));
                record.setCoursePeriod(rs.getString("zjw_Chour15"));
                record.setCourseExamination(rs.getString("zjw_Assessment_Type15"));
                record.setCourseNumber(rs.getString("zjw_Cno15"));
                record.setCourseTerm(rs.getString("zjw_Cterm15"));
                record.setTeacherName(rs.getString("zjw_Tname15"));
                records.add(record);
            }
            Dao.closeAll(conn, stat, rs);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return records;
    }

    @Override
    public ArrayList<Record> queryScore(String opt, String username) {
        ArrayList<Record> records = new ArrayList<>();
        String str = "";
        try {
            Connection conn = getConnection();
            if (!opt.equals("1")) {
                if (opt.equals("2")) str = "\'大一上\'";
                else if (opt.equals("3")) str = "\'大一下\'";
                else if (opt.equals("4")) str = "\'大二上\'";
                else if (opt.equals("5")) str = "\'大二下\'";
                else if (opt.equals("6")) str = "\'大三上\'";
                else if (opt.equals("7")) str = "\'大三下\'";
                else if (opt.equals("8")) str = "\'大四上\'";
                else if (opt.equals("9")) str = "\'大四下\'";
                str = " AND \"zjw_CourseTerm15\"=" + str;
            }
            String sql = "SELECT * FROM \"Zhangjw_GradeInfo15\" WHERE \"zjw_StudentNumber15\"=?" + str;
            PreparedStatement stat = conn.prepareStatement(sql);
            stat.setString(1, username);
            ResultSet rs = stat.executeQuery();
            while (rs.next()) {
                Record record = new Record();
                record.setStudentId(rs.getString("zjw_StudentNumber15"));
                record.setStudentName(rs.getString("zjw_StudentName15"));
                record.setClassName(rs.getString("zjw_ClassName15"));
                record.setCourseId(rs.getString("zjw_CourseNumber15"));
                record.setCourseName(rs.getString("zjw_CourseName15"));
                record.setScoreValue(rs.getString("zjw_Grade15"));
                record.setTeacherName(rs.getString("zjw_TeacherName15"));
                record.setCourseTerm(rs.getString("zjw_CourseTerm15"));
                records.add(record);
            }
            Dao.closeAll(conn, stat, rs);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return records;
    }

    @Override
    public ArrayList<Record> queryCredit(String opt, String username) {
        ArrayList<Record> records = new ArrayList<>();
        String str = "";
        try {
            Connection conn = getConnection();
            if (!opt.equals("1")) {
                if (opt.equals("2")) str = "\'大一上\'";
                else if (opt.equals("3")) str = "\'大一下\'";
                else if (opt.equals("4")) str = "\'大二上\'";
                else if (opt.equals("5")) str = "\'大二下\'";
                else if (opt.equals("6")) str = "\'大三上\'";
                else if (opt.equals("7")) str = "\'大三下\'";
                else if (opt.equals("8")) str = "\'大四上\'";
                else if (opt.equals("9")) str = "\'大四下\'";
                str = " AND \"zjw_CourseTerm15\"=" + str;
            }
            String sql = "SELECT * FROM \"Zhangjw_CreditInfo15\" WHERE \"zjw_StudentNumber15\"=?" + str;
            PreparedStatement stat = conn.prepareStatement(sql);
            stat.setString(1, username);
            ResultSet rs = stat.executeQuery();
            while (rs.next()) {
                Record record = new Record();
                record.setStudentId(rs.getString("zjw_StudentNumber15"));
                record.setStudentName(rs.getString("zjw_StudentName15"));
                record.setClassName(rs.getString("zjw_ClassName15"));
                record.setCourseName(rs.getString("zjw_CourseName15"));
                record.setCoursePeriod(rs.getString("zjw_CourseHours15"));
                record.setCourseCredit(rs.getString("zjw_CourseCredit15"));
                record.setGrade(rs.getString("zjw_Grade15"));
                record.setCourseTerm(rs.getString("zjw_CourseTerm15"));
                record.setGpa(rs.getString("zjw_PGA15"));
                records.add(record);
            }
            Dao.closeAll(conn, stat, rs);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return records;
    }

    @Override
    public ArrayList<Record> queryOwnCourse(String opt, String username) {
        ArrayList<Record> records = new ArrayList<>();
        String str = "";
        try {
            Connection conn = getConnection();
            if (!opt.equals("1")) {
                if (opt.equals("2")) str = "\'大一上\'";
                else if (opt.equals("3")) str = "\'大一下\'";
                else if (opt.equals("4")) str = "\'大二上\'";
                else if (opt.equals("5")) str = "\'大二下\'";
                else if (opt.equals("6")) str = "\'大三上\'";
                else if (opt.equals("7")) str = "\'大三下\'";
                else if (opt.equals("8")) str = "\'大四上\'";
                else if (opt.equals("9")) str = "\'大四下\'";
                str = " AND \"zjw_CourseTerm15\"=" + str;
            }
            String sql = "SELECT * FROM \"Zhangjw_GradeInfo15\" WHERE \"zjw_StudentNumber15\"=?" + str;
            PreparedStatement stat = conn.prepareStatement(sql);
            stat.setString(1, username);
            ResultSet rs = stat.executeQuery();
            while (rs.next()) {
                Record record = new Record();
                record.setStudentId(rs.getString("zjw_StudentNumber15"));
                record.setStudentName(rs.getString("zjw_StudentName15"));
                record.setCourseName(rs.getString("zjw_ClassName15"));
                record.setTeacherName(rs.getString("zjw_TeacherName15"));
                record.setCourseTerm(rs.getString("zjw_CourseTerm15"));
                record.setClassName(rs.getString("zjw_ClassName15"));
                records.add(record);
            }
            Dao.closeAll(conn, stat, rs);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return records;
    }
}
