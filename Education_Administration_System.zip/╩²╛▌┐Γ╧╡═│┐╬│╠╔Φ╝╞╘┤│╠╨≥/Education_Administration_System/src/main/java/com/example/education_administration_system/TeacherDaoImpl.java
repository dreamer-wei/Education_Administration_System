package com.example.education_administration_system;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class TeacherDaoImpl implements TeacherDao {
    @Override
    public ArrayList<Record> queryTeacherCourse(String opt, String query_value) {
        ArrayList<Record> records = new ArrayList<>();
        String str = "";
        if (opt.equals("2")) {
            str = " WHERE \"zjw_Tname15\"=?;";
        } else if (opt.equals("3")) {
            str = ",\"Zhangjw_Teachers15\" WHERE \"Zhangjw_Teachers15\".\"zjw_Tno15\"=? AND \"Zhangjw_Courses15\".\"zjw_Tname15\"=\"Zhangjw_Teachers15\".\"zjw_Tname15\"";
        }
        try {
            Connection conn = getConnection();
            query_value = new String(query_value.getBytes("iso-8859-1"), "UTF-8");
            String sql = "SELECT * FROM \"Zhangjw_Courses15\"" + str;
            PreparedStatement stat = conn.prepareStatement(sql);
            if (!opt.equals("1")) {
                stat.setString(1, query_value);
            }
            ResultSet rs = stat.executeQuery();
            while (rs.next()) {
                Record record = new Record();
                record.setCourseNumber(rs.getString("zjw_Cno15"));
                record.setCourseName(rs.getString("zjw_Cname15"));
                record.setCoursePeriod(rs.getString("zjw_Chour15"));
                record.setCourseCredit(rs.getString("zjw_Credit15"));
                record.setCourseTerm(rs.getString("zjw_Cterm15"));
                record.setCourseExamination(rs.getString("zjw_Assessment_Type15"));
                record.setTeacherName(rs.getString("zjw_Tname15"));
                records.add(record);
            }
            Dao.closeAll(conn, stat, rs);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return records;
    }

    @Override
    public ArrayList<Record> queryScoreAvg(String opt, String query_value) {
        ArrayList<Record> records = new ArrayList<>();
        String str = "";
        if (!opt.equals("1")) {
            str = " WHERE R.\"zjw_Cno15\"=? ";
        }
        try {
            Connection conn = getConnection();
            query_value = new String(query_value.getBytes("iso-8859-1"), "UTF-8");
            String sql = "SELECT R.\"zjw_Cno15\" AS zjw_cno15, C.\"zjw_Cname15\" AS zjw_cname15, ROUND(AVG(R.\"zjw_Grade15\"), 2) AS zjw_avg10" +
                    " FROM \"Zhangjw_Reports15\" AS R " +
                    "JOIN \"Zhangjw_Courses15\" AS C ON R.\"zjw_Cno15\"=C.\"zjw_Cno15\" " +
                    str +
                    "GROUP BY R.\"zjw_Cno15\", C.\"zjw_Cname15\";";
            PreparedStatement stat = conn.prepareStatement(sql);
            if (opt.equals("2")) {
                stat.setString(1, query_value);
            }
            ResultSet rs = stat.executeQuery();
            while (rs.next()) {
                Record record = new Record();
                record.setCourseId(rs.getString("zjw_cno15"));
                record.setCourseName(rs.getString("zjw_cname15"));
                record.setScoreValue(rs.getString("zjw_avg10"));
                records.add(record);
            }
            Dao.closeAll(conn, stat, rs);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return records;
    }

    @Override
    public ArrayList<Record> queryScoreRank(String opt, String query_value) {
        ArrayList<Record> records = new ArrayList<>();
        String str = "";
        if (opt.equals("1")) {
            str = "C.\"zjw_Cname15\"=?";
        } else if (opt.equals("2")) {
            str = "R.\"zjw_Cno15\"=?";
        }
        try {
            Connection conn = getConnection();
            query_value = new String(query_value.getBytes("iso-8859-1"), "UTF-8");
            String sql = "SELECT R.\"zjw_Cno15\",\"zjw_Cname15\",\"zjw_Sname15\",\"zjw_Grade15\",T.\"zjw_Tname15\" "
                    + "FROM \"Zhangjw_Reports15\" AS R"
                    + "\tJOIN \"Zhangjw_Students15\" AS S ON R.\"zjw_Sno15\"=S.\"zjw_Sno15\""
                    + "\tJOIN \"Zhangjw_Teachers15\" AS T ON R.\"zjw_Tno15\"=T.\"zjw_Tno15\""
                    + "\tJOIN \"Zhangjw_Courses15\" AS C ON R.\"zjw_Cno15\"=C.\"zjw_Cno15\""
                    + "WHERE " + str + "ORDER BY \"zjw_Grade15\" DESC;";
            PreparedStatement stat = conn.prepareStatement(sql);
            if (!opt.equals("3")) {
                stat.setString(1, query_value);
            }
            ResultSet rs = stat.executeQuery();
            int rank = 1;
            while (rs.next()) {
                Record record = new Record();
                record.setStudentName(rs.getString("zjw_Sname15"));
                record.setCourseName(rs.getString("zjw_Cname15"));
                record.setCourseId(rs.getString("zjw_Cno15"));
                record.setScoreValue(rs.getString("zjw_Grade15"));
                record.setTeacherName(rs.getString("zjw_Tname15"));
                record.setCount(Integer.toString(rank));
                rank++;
                records.add(record);
            }
            Dao.closeAll(conn, stat, rs);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return records;
    }

    @Override
    public Boolean importStudent(Record record) {
        String sql;
        try {
            Connection conn = getConnection();
            sql = "SELECT * FROM \"Zhangjw_Courses15\",\"Zhangjw_Teachers15\" WHERE \"Zhangjw_Courses15\".\"zjw_Tname15\"=\"Zhangjw_Teachers15\".\"zjw_Tname15\" AND \"Zhangjw_Teachers15\".\"zjw_Tno15\"=?;";
            PreparedStatement stat = conn.prepareStatement(sql);
            stat.setString(1, record.getTeacherId());
            ResultSet rs1 = stat.executeQuery();
            sql = "SELECT * FROM \"Zhangjw_Students15\",\"Zhangjw_CourseClass15\" WHERE \"Zhangjw_Students15\".\"zjw_Sno15\"=? AND \"Zhangjw_Students15\".\"zjw_CLno15\"=\"Zhangjw_CourseClass15\".\"zjw_CLno15\" AND \"Zhangjw_CourseClass15\".\"zjw_Cno15\"=?;";
            stat = conn.prepareStatement(sql);
            stat.setString(1, record.getStudentId());
            stat.setString(2, record.getCourseId());
            ResultSet rs2 = stat.executeQuery();
            if (!rs1.next()) {
                System.out.println(1);
                return false;
            }
            if (!rs2.next()) {
                System.out.println(2);
                return false;
            }
            sql = "INSERT INTO \"Zhangjw_Reports15\" VALUES(?,?,?,?,?);";
            stat = conn.prepareStatement(sql);
            stat.setString(1, record.getStudentId());
            stat.setString(2, record.getCourseId());
            stat.setString(3, record.getCourseTerm());
            stat.setString(4, record.getScoreValue());
            stat.setString(5, record.getTeacherId());
            int rows = stat.executeUpdate();
            Dao.closeAll(conn, stat, null);
            if (rows != 0) return true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
}
