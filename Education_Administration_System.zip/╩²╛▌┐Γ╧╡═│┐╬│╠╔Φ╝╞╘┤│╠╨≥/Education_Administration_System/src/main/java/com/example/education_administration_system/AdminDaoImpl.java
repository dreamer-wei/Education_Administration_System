package com.example.education_administration_system;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class AdminDaoImpl implements AdminDao {
    @Override
    public boolean updateStudent(String opt, String username, String update_value) {
        String str;
        if (opt.equals("1")) str = "\"zjw_Location15\"";
        else if (opt.equals("2")) str = "\"zjw_Sage15\"";
        else str = "\"zjw_Scredit15\"";
        try {
            Connection conn = getConnection();
            update_value = new String(update_value.getBytes("iso-8859-1"), "UTF-8");
            PreparedStatement stat = conn.prepareStatement("UPDATE \"Zhangjw_Students15\" SET " + str + "=? WHERE \"zjw_Sno15\"=?");
            stat.setString(1, update_value);
            stat.setString(2, username);
            int rows = stat.executeUpdate();
            if (rows == 0) return false;
            Dao.closeAll(conn, stat, null);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return true;
    }

    @Override
    public boolean updateTeacher(String opt, String username, String update_value) {
        String str;
        if (opt.equals("1")) str = "\"zjw_Tjob15\"";
        else if (opt.equals("2")) str = "\"zjw_Tage15\"";
        else str = "\"zjw_Tphone15\"";
        try {
            Connection conn = getConnection();
            update_value = new String(update_value.getBytes("iso-8859-1"), "UTF-8");
            PreparedStatement stat = conn.prepareStatement("UPDATE \"Zhangjw_Teachers15\" SET " + str + "=? WHERE \"zjw_Tno15\"=?");
            stat.setString(1, update_value);
            stat.setString(2, username);
            int rows = stat.executeUpdate();
            if (rows == 0) return false;
            Dao.closeAll(conn, stat, null);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return true;
    }

    @Override
    public boolean updateCourse(String username, String update_value) {
        try {
            Connection conn = getConnection();
            update_value = new String(update_value.getBytes("iso-8859-1"), "UTF-8");
            PreparedStatement stat = conn.prepareStatement("UPDATE \"Zhangjw_Courses15\" SET \"zjw_Cterm15\"=? WHERE \"zjw_Cno15\"=?");
            stat.setString(1, update_value);
            stat.setString(2, username);
            int rows = stat.executeUpdate();
            if (rows == 0) return false;
            Dao.closeAll(conn, stat, null);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return true;
    }

    @Override
    public boolean resetPwd(String role, String username) {
        String table, pwd, num;
        if (role.equals("1")) {
            table = "\"Zhangjw_Students15\"";
            pwd = "\"zjw_Spassword15\"";
            num = "\"zjw_Sno15\"";
        } else {
            table = "\"Zhangjw_Teachers15\"";
            pwd = "\"zjw_Tpassword15\"";
            num = "\"zjw_Tno15\"";
        }
        try {
            Connection conn = getConnection();
            username = new String(username.getBytes("iso-8859-1"), "UTF-8");
            PreparedStatement stat = conn.prepareStatement("UPDATE " + table + " SET " + pwd + "=\'123456\' WHERE " + num + "=?");
            stat.setString(1, username);
            int rows = stat.executeUpdate();
            if (rows == 0) return false;
            Dao.closeAll(conn, stat, null);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return true;
    }

    @Override
    public boolean registerNew(String role, Record record) {
        if (role.equals("1")) {
            String sql = "INSERT INTO \"Zhangjw_Teachers15\" VALUES(?,?,?,?,?,?);";
            try {
                Connection conn = getConnection();
                PreparedStatement stat = conn.prepareStatement(sql);
                stat.setString(1, record.getTeacherId());
                stat.setString(2, new String(record.getTeacherName().getBytes("iso-8859-1"), "UTF-8"));
                stat.setString(3, record.getTeacherSex().equals("1") ? "男" : "女");
                stat.setString(4, record.getTeacherAge());
                stat.setString(5, new String(record.getTeacherTitle().getBytes("iso-8859-1"), "UTF-8"));
                stat.setString(6, record.getTeacherPhone());
                int rows = stat.executeUpdate();
                Dao.closeAll(conn, stat, null);
                if (rows != 0) return true;
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if (role.equals("2")) {
            String sql;
            sql = "INSERT INTO \"Zhangjw_Students15\" VALUES(?,?,?,?,?,0,?);";
            try {
                Connection conn = getConnection();
                PreparedStatement stat = conn.prepareStatement(sql);
                stat.setString(1, record.getStudentId());
                stat.setString(2, new String(record.getStudentName().getBytes("iso-8859-1"), "UTF-8"));
                stat.setString(3, record.getStudentSex().equals("1") ? "男" : "女");
                stat.setString(4, record.getStudentAge());
                stat.setString(5, new String(record.getStudentRegion().getBytes("iso-8859-1"), "UTF-8"));
                stat.setString(6, record.getClassNumber());
                int rows = stat.executeUpdate();
                Dao.closeAll(conn, stat, null);
                if (rows != 0) return true;
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else return false;
        return false;
    }

    @Override
    public ArrayList<Record> queryRegion(String opt, String query_value) {
        ArrayList<Record> records = new ArrayList<>();
        String str = "";
        if (!opt.equals("1")) {
            str = " WHERE \"zjw_Location15\"=?";
        }
        try {
            Connection conn = getConnection();
            query_value = new String(query_value.getBytes("iso-8859-1"), "UTF-8");
            String sql = "SELECT \"zjw_Location15\",COUNT(*) AS number FROM \"Zhangjw_StudentInfo15\"" + str + " GROUP BY \"zjw_Location15\";";
            PreparedStatement stat = conn.prepareStatement(sql);
            if (opt.equals("2")) {
                stat.setString(1, query_value);
            }
            ResultSet rs = stat.executeQuery();
            while (rs.next()) {
                Record record = new Record();
                record.setStudentRegion(rs.getString("zjw_Location15"));
                record.setCount(rs.getString("number"));
                records.add(record);
            }
            Dao.closeAll(conn, stat, rs);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return records;
    }

    @Override
    public ArrayList<Record> queryStudent(String opt, String query_value) {
        ArrayList<Record> records = new ArrayList<>();
        String str = "";
        if (opt.equals("2")) {
            str = " WHERE \"zjw_StudentNumber15\"=?;";
        } else if (opt.equals("3")) {
            str = " WHERE \"zjw_StudentName15\"=?;";
        } else if (opt.equals("4")) {
            str = " WHERE \"zjw_MajorName15\"=?;";
        } else if (opt.equals("5")) {
            str = " WHERE \"zjw_ClassName15\"=?;";
        }
        try {
            Connection conn = getConnection();
            query_value = new String(query_value.getBytes("iso-8859-1"), "UTF-8");
            String sql = "SELECT * FROM \"Zhangjw_StudentInfo15\"" + str;
            PreparedStatement stat = conn.prepareStatement(sql);
            if (!opt.equals("1")) {
                stat.setString(1, query_value);
            }
            ResultSet rs = stat.executeQuery();
            while (rs.next()) {
                Record record = new Record();
                record.setStudentId(rs.getString("zjw_StudentNumber15"));
                record.setStudentName(rs.getString("zjw_StudentName15"));
                record.setStudentSex(rs.getString("zjw_StudentSex15"));
                record.setStudentAge(rs.getString("zjw_StudentAge15"));
                record.setStudentRegion(rs.getString("zjw_Location15"));
                record.setMajorName(rs.getString("zjw_MajorName15"));
                record.setClassName(rs.getString("zjw_ClassName15"));
                record.setStudentCredits(rs.getString("zjw_StudentCredit15"));
                records.add(record);
            }
            Dao.closeAll(conn, stat, rs);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return records;
    }

    @Override
    public ArrayList<Record> queryTeacher(String opt, String query_value) {
        ArrayList<Record> records = new ArrayList<>();
        String str = "";
        if (opt.equals("2")) {
            str = " WHERE \"zjw_Tno15\"=?;";
        } else if (opt.equals("3")) {
            str = " WHERE \"zjw_Tname15\"=?;";
        }
        try {
            Connection conn = getConnection();
            query_value = new String(query_value.getBytes("iso-8859-1"), "UTF-8");
            String sql = "SELECT * FROM \"Zhangjw_Teachers15\"" + str;
            PreparedStatement stat = conn.prepareStatement(sql);
            if (!opt.equals("1")) {
                stat.setString(1, query_value);
            }
            ResultSet rs = stat.executeQuery();
            while (rs.next()) {
                Record record = new Record();
                record.setTeacherId(rs.getString("zjw_Tno15"));
                record.setTeacherName(rs.getString("zjw_Tname15"));
                record.setTeacherSex(rs.getString("zjw_Tsex15"));
                record.setTeacherAge(rs.getString("zjw_Tage15"));
                record.setTeacherTitle(rs.getString("zjw_Tjob15"));
                record.setTeacherPhone(rs.getString("zjw_Tphone15"));
                records.add(record);
            }
            Dao.closeAll(conn, stat, rs);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return records;
    }

    @Override
    public ArrayList<Record> queryClass(String opt, String query_value) {
        ArrayList<Record> records = new ArrayList<>();
        String str = "";
        if (opt.equals("2")) {
            str = "\"zjw_Mname15\"=? AND";
        } else if (opt.equals("3")) {
            str = "\"zjw_CLname15\"=? AND";
        }
        try {
            Connection conn = getConnection();
            query_value = new String(query_value.getBytes("iso-8859-1"), "UTF-8");
            String sql = "SELECT \"zjw_Mname15\",\"zjw_CLname15\" " +
                    "FROM \"Zhangjw_Classes15\" AS C,\"Zhangjw_Majors15\" AS M WHERE " + str + " C.\"zjw_Mno15\"=M.\"zjw_Mno15\";";
            PreparedStatement stat = conn.prepareStatement(sql);
            if (!opt.equals("1")) {
                stat.setString(1, query_value);
            }
            ResultSet rs = stat.executeQuery();
            while (rs.next()) {
                Record record = new Record();
                record.setMajorName(rs.getString("zjw_Mname15"));
                record.setClassName(rs.getString("zjw_CLname15"));
                records.add(record);
            }
            Dao.closeAll(conn, stat, rs);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return records;
    }

    @Override
    public ArrayList<Record> queryMajor(String opt, String query_value) {
        ArrayList<Record> records = new ArrayList<>();
        String str = "";
        if (opt.equals("2")) {
            str = " WHERE \"zjw_Mname15\"=?;";
        }
        try {
            Connection conn = getConnection();
            query_value = new String(query_value.getBytes("iso-8859-1"), "UTF-8");
            String sql = "SELECT * FROM \"Zhangjw_Majors15\"" + str;
            PreparedStatement stat = conn.prepareStatement(sql);
            if (!opt.equals("1")) {
                stat.setString(1, query_value);
            }
            ResultSet rs = stat.executeQuery();
            while (rs.next()) {
                Record record = new Record();
                record.setMajorId(rs.getString("zjw_Mno15"));
                record.setMajorName(rs.getString("zjw_Mname15"));
                records.add(record);
            }
            Dao.closeAll(conn, stat, rs);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return records;
    }

    @Override
    public ArrayList<Record> queryCourse(String opt, String query_value) {
        ArrayList<Record> records = new ArrayList<>();
        String str = "";
        if (opt.equals("2")) {
            str = " WHERE \"zjw_CourseNumber15\"=?;";
        } else if (opt.equals("3")) {
            str = " WHERE \"zjw_CourseName15\"=?;";
        } else if (opt.equals("4")) {
            str = " WHERE \"zjw_TeacherName15\"=?;";
        }
        try {
            Connection conn = getConnection();
            query_value = new String(query_value.getBytes("iso-8859-1"), "UTF-8");
            String sql = "SELECT * FROM \"Zhangjw_ClassInfo15\"" + str;
            PreparedStatement stat = conn.prepareStatement(sql);
            if (!opt.equals("1")) {
                stat.setString(1, query_value);
            }
            ResultSet rs = stat.executeQuery();
            while (rs.next()) {
                Record record = new Record();
                record.setCourseName(rs.getString("zjw_CourseName15"));
                record.setCourseCredit(rs.getString("zjw_CourseCredit15"));
                record.setCoursePeriod(rs.getString("zjw_CourseHours15"));
                record.setCourseExamination(rs.getString("zjw_AssessmentType15"));
                record.setCourseNumber(rs.getString("zjw_CourseNumber15"));
                record.setClassName(rs.getString("zjw_ClassName15"));
                record.setCourseTerm(rs.getString("zjw_CourseTerm15"));
                record.setTeacherName(rs.getString("zjw_TeacherName15"));
                records.add(record);
            }
            Dao.closeAll(conn, stat, rs);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return records;
    }
}
