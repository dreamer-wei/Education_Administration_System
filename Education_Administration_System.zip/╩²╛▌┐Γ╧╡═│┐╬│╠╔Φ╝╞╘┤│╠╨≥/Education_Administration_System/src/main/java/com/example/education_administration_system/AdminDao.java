package com.example.education_administration_system;

import java.util.ArrayList;

public interface AdminDao extends Dao {
    public boolean updateStudent(String opt, String username, String update_value);

    public boolean updateTeacher(String opt, String username, String update_value);

    public boolean updateCourse(String username, String update_value);

    public boolean resetPwd(String role, String username);

    public boolean registerNew(String role, Record record);

    public ArrayList<Record> queryRegion(String opt, String query_value);

    public ArrayList<Record> queryStudent(String opt, String query_value);

    public ArrayList<Record> queryTeacher(String opt, String query_value);

    public ArrayList<Record> queryClass(String opt, String query_value);

    public ArrayList<Record> queryMajor(String opt, String query_value);

    public ArrayList<Record> queryCourse(String opt, String query_value);
}
