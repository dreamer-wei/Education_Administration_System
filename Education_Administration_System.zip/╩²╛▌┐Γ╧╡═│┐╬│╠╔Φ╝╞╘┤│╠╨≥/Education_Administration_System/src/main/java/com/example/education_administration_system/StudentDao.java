package com.example.education_administration_system;

import java.util.ArrayList;

public interface StudentDao extends Dao {
    public ArrayList<Record> queryClassCourse(String opt, String query_value);

    public ArrayList<Record> queryTeacherCourse(String opt, String query_value);

    public ArrayList<Record> queryScore(String opt, String username);

    public ArrayList<Record> queryCredit(String opt, String username);

    public ArrayList<Record> queryOwnCourse(String opt, String query_value);
}
